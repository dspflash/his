use his;
TRUNCATE TABLE status_option;
