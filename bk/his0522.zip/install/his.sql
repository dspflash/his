-- MySQL dump 10.11
--
-- Host: localhost    Database: his
-- ------------------------------------------------------
-- Server version	5.0.51b-community-nt-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `his`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `his` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `his`;

--
-- Table structure for table `bottle_info`
--

DROP TABLE IF EXISTS `bottle_info`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bottle_info` (
  `bottleid` bigint(20) NOT NULL auto_increment,
  `bottleno` varchar(50) default NULL COMMENT '瓶号',
  `medicineid` bigint(20) default NULL,
  `medicineno` varchar(50) default NULL COMMENT '药码',
  `weight_gross` double(18,2) default NULL COMMENT '毛重(标)',
  `weight_net` double(18,2) default NULL COMMENT '净重(标)',
  `weight_initial` double(18,2) default NULL COMMENT '初始重量',
  `weight_last` double(18,2) default NULL,
  `weight_cur` double(18,2) default NULL COMMENT '当前重量',
  `opera` int(11) default '0' COMMENT '操作者',
  `uptime` datetime default NULL COMMENT '更新时间',
  `uses_flag` tinyint(4) default '100' COMMENT '使用状态',
  `remark` varchar(50) default NULL COMMENT '备注',
  PRIMARY KEY  (`bottleid`),
  UNIQUE KEY `bottleno` (`bottleno`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='药瓶基本信息';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bottle_info`
--

LOCK TABLES `bottle_info` WRITE;
/*!40000 ALTER TABLE `bottle_info` DISABLE KEYS */;
INSERT INTO `bottle_info` VALUES (1,'BOT202105150001',1,'H0201900',120.00,100.00,NULL,100.00,100.00,1,'2021-05-17 14:14:40',104,NULL),(2,'BOT202105150002',1,'H0201900',120.00,100.00,NULL,NULL,NULL,1,'2021-05-16 15:22:20',101,NULL),(3,'BOT202105150003',2,'H0201901',100.00,80.00,NULL,NULL,NULL,1,'2021-05-16 15:27:41',103,NULL),(4,'BOT202105160001',3,'H0201902',130.00,110.00,NULL,0.00,80.00,1,'2021-05-17 11:11:23',107,''),(5,'BOT202105170001',4,'H0201903',110.00,90.00,NULL,NULL,NULL,1,'2021-05-17 16:33:32',100,'ddddd');
/*!40000 ALTER TABLE `bottle_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bottle_loc_cabinet`
--

DROP TABLE IF EXISTS `bottle_loc_cabinet`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bottle_loc_cabinet` (
  `locationid` bigint(20) NOT NULL auto_increment,
  `equipmentno` varchar(50) default NULL COMMENT '设备编码',
  `bottleid` int(11) default NULL COMMENT '药瓶编码',
  `bottleno` varchar(50) default NULL COMMENT '药瓶编码',
  `medicineid` int(11) default NULL,
  `medicineno` varchar(50) default NULL,
  `cabinetid` int(11) default NULL COMMENT '药柜',
  `cellid` varchar(50) default NULL COMMENT '药柜柜格',
  `isdel` tinyint(1) default '0',
  `opera` int(11) default NULL COMMENT '操作员',
  `uptime` datetime default NULL COMMENT '更新时间',
  PRIMARY KEY  (`locationid`),
  UNIQUE KEY `medicineid` (`medicineid`),
  UNIQUE KEY `cabinet_cellid` (`cabinetid`,`cellid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='药格配置';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bottle_loc_cabinet`
--

LOCK TABLES `bottle_loc_cabinet` WRITE;
/*!40000 ALTER TABLE `bottle_loc_cabinet` DISABLE KEYS */;
INSERT INTO `bottle_loc_cabinet` VALUES (3,NULL,1,'BOT202105150001',1,'H0201900',1,'1',0,1,'2021-05-16 15:26:15'),(4,NULL,3,'BOT202105150003',2,'H0201901',1,'2',0,1,'2021-05-16 15:27:41'),(5,NULL,4,'BOT202105160001',3,'H0201902',1,'3',0,1,'2021-05-16 15:30:16');
/*!40000 ALTER TABLE `bottle_loc_cabinet` ENABLE KEYS */;
UNLOCK TABLES;

/*!50003 SET @SAVE_SQL_MODE=@@SQL_MODE*/;

DELIMITER ;;
/*!50003 SET SESSION SQL_MODE="" */;;
/*!50003 CREATE */ /*!50017 DEFINER=`i3u`@`localhost` */ /*!50003 TRIGGER `bottle_loc_cabinet_insert` AFTER INSERT ON `bottle_loc_cabinet` FOR EACH ROW BEGIN
#update bottle_info set uses_flag=103 where bottleid=new.bottleid;
INSERT INTO bottle_transaction (bottleid,medicineid,opera,uptime,uses_flag) VALUES(
new.bottleid,new.medicineid,new.opera,new.uptime,103);
    END */;;

/*!50003 SET SESSION SQL_MODE="" */;;
/*!50003 CREATE */ /*!50017 DEFINER=`i3u`@`localhost` */ /*!50003 TRIGGER `bottle_loc_cabinet_update_isdel` BEFORE UPDATE ON `bottle_loc_cabinet` FOR EACH ROW BEGIN
    if old.isdel=0 and new.isdel=1 then
INSERT INTO bottle_transaction (bottleid,medicineid,weight_cur,opera,uptime,uses_flag) VALUES(
old.bottleid,old.medicineid,new.opera,NOW(),108);
end if;
    END */;;

DELIMITER ;
/*!50003 SET SESSION SQL_MODE=@SAVE_SQL_MODE*/;

--
-- Table structure for table `bottle_log`
--

DROP TABLE IF EXISTS `bottle_log`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bottle_log` (
  `bottle_logid` bigint(20) NOT NULL auto_increment,
  `bottleid` bigint(20) NOT NULL,
  `bottleno` varchar(50) default NULL COMMENT '瓶号',
  `medicineid` bigint(20) default NULL,
  `medicineno` varchar(50) default NULL COMMENT '药码',
  `qty` double(18,2) default NULL COMMENT '当前重量',
  `opera` int(11) default NULL COMMENT '操作者',
  `uptime` datetime default NULL COMMENT '更新时间',
  `uses_flag` tinyint(4) default '0',
  `datecode` int(11) default NULL,
  PRIMARY KEY  (`bottle_logid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='药瓶使用流水账';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bottle_log`
--

LOCK TABLES `bottle_log` WRITE;
/*!40000 ALTER TABLE `bottle_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `bottle_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bottle_transaction`
--

DROP TABLE IF EXISTS `bottle_transaction`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bottle_transaction` (
  `bottle_transactionid` bigint(20) NOT NULL auto_increment,
  `bottleid` bigint(20) NOT NULL,
  `bottleno` varchar(50) default NULL COMMENT '瓶号',
  `medicineid` bigint(20) default NULL,
  `medicineno` varchar(50) default NULL COMMENT '药码',
  `weight_cur` double(18,2) default NULL COMMENT '当前重量',
  `opera` int(11) default NULL COMMENT '操作者',
  `uptime` datetime default NULL COMMENT '更新时间',
  `uses_flag` tinyint(4) default '0' COMMENT '使用状态',
  `reftbl` varchar(50) default NULL,
  `refid` bigint(20) default NULL,
  PRIMARY KEY  (`bottle_transactionid`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COMMENT='药瓶基本信息备份';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bottle_transaction`
--

LOCK TABLES `bottle_transaction` WRITE;
/*!40000 ALTER TABLE `bottle_transaction` DISABLE KEYS */;
INSERT INTO `bottle_transaction` VALUES (1,1,NULL,1,NULL,0.00,1,'2021-05-16 15:22:12',101,'',0),(2,2,NULL,1,NULL,0.00,1,'2021-05-16 15:22:20',101,'',0),(3,3,NULL,2,NULL,0.00,1,'2021-05-16 15:22:31',101,'',0),(4,1,NULL,1,NULL,NULL,1,'2021-05-16 15:26:15',103,NULL,NULL),(5,3,NULL,2,NULL,NULL,1,'2021-05-16 15:27:41',103,NULL,NULL),(6,4,NULL,3,NULL,0.00,1,'2021-05-16 15:30:00',101,'',0),(7,4,NULL,3,NULL,NULL,1,'2021-05-16 15:30:16',103,NULL,NULL),(8,1,NULL,1,NULL,100.00,1,'2021-05-17 11:00:21',104,NULL,NULL),(9,1,NULL,1,NULL,NULL,1,'2021-05-17 11:02:07',105,NULL,NULL),(10,1,NULL,1,NULL,NULL,1,'2021-05-17 11:02:23',105,NULL,NULL),(11,1,NULL,1,NULL,NULL,1,'2021-05-17 11:02:42',105,NULL,NULL),(12,1,NULL,1,NULL,80.00,1,'2021-05-17 11:02:56',106,NULL,NULL),(13,1,NULL,1,NULL,NULL,1,'2021-05-17 11:03:21',107,NULL,NULL),(14,1,NULL,1,NULL,0.00,1,'2021-05-17 11:04:07',108,'',0),(15,4,NULL,3,NULL,0.00,1,'2021-05-17 11:09:18',104,NULL,NULL),(16,4,NULL,3,NULL,NULL,1,'2021-05-17 11:09:41',105,NULL,NULL),(17,4,NULL,3,NULL,NULL,1,'2021-05-17 11:09:52',105,NULL,NULL),(18,4,NULL,3,NULL,0.00,1,'2021-05-17 11:10:05',106,NULL,NULL),(19,4,NULL,3,NULL,0.00,1,'2021-05-17 11:10:15',106,NULL,NULL),(20,4,NULL,3,NULL,80.00,1,'2021-05-17 11:10:59',106,NULL,NULL),(21,4,NULL,3,NULL,NULL,1,'2021-05-17 11:11:23',107,NULL,NULL),(22,1,NULL,1,NULL,0.00,1,'2021-05-17 11:17:28',106,NULL,NULL),(23,1,NULL,1,NULL,100.00,1,'2021-05-17 14:03:45',104,NULL,NULL),(24,1,NULL,1,NULL,100.00,1,'2021-05-17 14:06:10',104,NULL,NULL),(25,1,NULL,1,NULL,100.00,1,'2021-05-17 14:10:30',104,NULL,NULL),(26,1,NULL,1,NULL,100.00,1,'2021-05-17 14:11:59',104,NULL,NULL),(27,1,NULL,1,NULL,100.00,1,'2021-05-17 14:13:49',104,NULL,NULL),(28,1,NULL,1,NULL,100.00,1,'2021-05-17 14:14:40',104,NULL,NULL);
/*!40000 ALTER TABLE `bottle_transaction` ENABLE KEYS */;
UNLOCK TABLES;

/*!50003 SET @SAVE_SQL_MODE=@@SQL_MODE*/;

DELIMITER ;;
/*!50003 SET SESSION SQL_MODE="" */;;
/*!50003 CREATE */ /*!50017 DEFINER=`i3u`@`localhost` */ /*!50003 TRIGGER `bottle_transaction_insert` BEFORE INSERT ON `bottle_transaction` FOR EACH ROW BEGIN
IF new.uses_flag=104 THEN
UPDATE bottle_info SET weight_initial=IF(weight_initial,new.weight_cur,weight_initial),weight_last=weight_cur,weight_cur=new.weight_cur,uses_flag=new.uses_flag,opera=new.opera,uptime=new.uptime WHERE bottleid=new.bottleid;
ELSEIF new.uses_flag=106 THEN
UPDATE bottle_info SET weight_last=weight_cur,weight_cur=new.weight_cur,uses_flag=new.uses_flag,opera=new.opera,uptime=new.uptime WHERE bottleid=new.bottleid;
ELSE
UPDATE bottle_info SET uses_flag=new.uses_flag,opera=new.opera,uptime=new.uptime WHERE bottleid=new.bottleid;
END IF;
    END */;;

DELIMITER ;
/*!50003 SET SESSION SQL_MODE=@SAVE_SQL_MODE*/;

--
-- Table structure for table `cabinet`
--

DROP TABLE IF EXISTS `cabinet`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cabinet` (
  `cabinetid` int(11) NOT NULL auto_increment COMMENT '序号',
  `cabinetname` varchar(50) default NULL COMMENT '柜名',
  `layout_row` tinyint(4) default NULL COMMENT '药柜行数',
  `layout_col` tinyint(4) default NULL COMMENT '药柜列数',
  `layout_rowwidth` smallint(6) default NULL COMMENT '药格宽',
  `layout_rowheight` smallint(6) default NULL COMMENT '药格高',
  `status` tinyint(1) default NULL COMMENT '状态',
  `opera` int(11) default NULL COMMENT '操作员',
  `uptime` datetime default NULL COMMENT '更新时间',
  `bind` int(11) default NULL COMMENT '绑定设备',
  PRIMARY KEY  (`cabinetid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='药柜信息';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cabinet`
--

LOCK TABLES `cabinet` WRITE;
/*!40000 ALTER TABLE `cabinet` DISABLE KEYS */;
INSERT INTO `cabinet` VALUES (1,'YAOGUI1',23,16,160,80,1,1,'2021-05-15 10:58:53',0),(2,'YAOGUI2',23,16,160,80,1,1,'2021-05-15 11:04:34',0);
/*!40000 ALTER TABLE `cabinet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cabinet_cell`
--

DROP TABLE IF EXISTS `cabinet_cell`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `cabinet_cell` (
  `cellid` int(11) NOT NULL auto_increment,
  `cabinetid` int(11) NOT NULL,
  `cell_row` tinyint(4) NOT NULL,
  `cell_col` tinyint(4) NOT NULL,
  `op_idx` int(11) default NULL COMMENT 'modbus regs index, eg:1,2,3,4,5',
  `op_code` int(11) default NULL COMMENT 'modbus reg code,eg:1,2,4,8,16',
  `opera` int(11) default NULL,
  `uptime` datetime default NULL,
  PRIMARY KEY  (`cellid`),
  KEY `FK_cabinet_cell` (`cabinetid`),
  CONSTRAINT `FK_cabinet_cell` FOREIGN KEY (`cabinetid`) REFERENCES `cabinet` (`cabinetid`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `cabinet_cell`
--

LOCK TABLES `cabinet_cell` WRITE;
/*!40000 ALTER TABLE `cabinet_cell` DISABLE KEYS */;
INSERT INTO `cabinet_cell` VALUES (1,1,1,1,1,1,0,'2021-05-14 16:13:47'),(2,1,1,2,1,2,0,'2021-05-14 16:14:03'),(3,1,1,3,1,4,0,'2021-05-14 16:14:19'),(4,1,1,4,1,8,0,'2021-05-14 16:14:34'),(5,1,1,5,1,16,0,'2021-05-14 21:03:15');
/*!40000 ALTER TABLE `cabinet_cell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `computers`
--

DROP TABLE IF EXISTS `computers`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `computers` (
  `computerid` int(11) NOT NULL auto_increment,
  `dispensaryid` int(11) default NULL,
  `computer_mac` varchar(40) default NULL COMMENT '计算机mac',
  `computer_name` varchar(40) default NULL COMMENT '计算机名',
  `computer_ip` varchar(40) default NULL COMMENT '计算机ip',
  `memo` varchar(50) default NULL COMMENT '备注',
  `opera` int(11) default NULL COMMENT '操作者',
  `uptime` datetime default NULL COMMENT '添加时间',
  `delemp` int(11) default NULL COMMENT '删除人',
  `deltime` datetime default NULL COMMENT '删除时间',
  `valid` tinyint(2) default NULL COMMENT '状态',
  PRIMARY KEY  (`computerid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='本机匹配设备';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `computers`
--

LOCK TABLES `computers` WRITE;
/*!40000 ALTER TABLE `computers` DISABLE KEYS */;
INSERT INTO `computers` VALUES (1,1,'00:50:56:C0:00:08','adminpc','192.168.0.188','',1,'2021-05-15 15:28:19',0,'0000-00-00 00:00:00',0);
/*!40000 ALTER TABLE `computers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `department` (
  `departmentid` smallint(6) NOT NULL auto_increment,
  `departname` varchar(50) default NULL COMMENT '部门名',
  `empid` smallint(6) default NULL COMMENT '工号',
  `empname` varchar(15) default NULL COMMENT '名字',
  `opera` int(11) default NULL COMMENT '操作者',
  `uptime` datetime default NULL COMMENT '更新时间',
  PRIMARY KEY  (`departmentid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='部门人员';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,'技术部',NULL,NULL,0,'2021-05-12 19:35:35');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dispensary`
--

DROP TABLE IF EXISTS `dispensary`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `dispensary` (
  `dispensaryid` int(11) NOT NULL auto_increment,
  `hospitalid` int(11) default '1',
  `dispensaryno` varchar(5) default NULL COMMENT '药房码',
  `dispensaryname` varchar(50) default NULL COMMENT '药房名',
  `memo` varchar(50) default NULL COMMENT '备注',
  `opera` int(11) default NULL COMMENT '操作员',
  `uptime` datetime default NULL COMMENT '时间',
  `delemp` int(11) default NULL COMMENT '删除人',
  `deltime` datetime default NULL COMMENT '删除时间',
  `status` tinyint(2) default NULL COMMENT '状态',
  PRIMARY KEY  (`dispensaryid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='药房基本信息';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `dispensary`
--

LOCK TABLES `dispensary` WRITE;
/*!40000 ALTER TABLE `dispensary` DISABLE KEYS */;
INSERT INTO `dispensary` VALUES (1,1,'DP01','中药制剂药房','',1,NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `dispensary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `equipment` (
  `equipmentid` int(11) NOT NULL auto_increment COMMENT '序号',
  `computerid` int(11) default '1',
  `equipmentno` varchar(20) default NULL COMMENT '设备编号',
  `equipmentname` varchar(50) default NULL COMMENT '设备名',
  `ip` varchar(50) default NULL COMMENT 'ip',
  `cabinetid` int(11) default NULL COMMENT '药柜号',
  `status` tinyint(1) default NULL COMMENT '状态',
  `equipmenttypeid` tinyint(4) default NULL,
  `equipmenttype` varchar(30) default NULL COMMENT '设备类型',
  `opera` int(11) default NULL COMMENT '操作者',
  `uptime` datetime default NULL COMMENT '时间',
  PRIMARY KEY  (`equipmentid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='药柜设备';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `equipment`
--

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
INSERT INTO `equipment` VALUES (1,1,'SBNO1','SBNO1','192.168.0.200',1,1,0,'',1,'2021-05-15 15:29:27');
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment_pos`
--

DROP TABLE IF EXISTS `equipment_pos`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `equipment_pos` (
  `posid` int(11) NOT NULL auto_increment,
  `equipmentid` int(11) NOT NULL,
  `pos_idx` tinyint(4) NOT NULL,
  `opera` int(11) default NULL,
  `uptime` datetime default NULL,
  PRIMARY KEY  (`posid`),
  KEY `FK_equipment_pos` (`equipmentid`),
  CONSTRAINT `FK_equipment_pos` FOREIGN KEY (`equipmentid`) REFERENCES `equipment` (`equipmentid`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `equipment_pos`
--

LOCK TABLES `equipment_pos` WRITE;
/*!40000 ALTER TABLE `equipment_pos` DISABLE KEYS */;
INSERT INTO `equipment_pos` VALUES (1,1,1,0,'2021-05-14 21:45:24'),(2,1,2,0,'2021-05-14 21:45:32'),(3,1,3,0,'2021-05-14 21:45:38'),(4,1,4,0,'2021-05-14 21:45:45'),(5,1,5,0,'2021-05-14 21:45:50');
/*!40000 ALTER TABLE `equipment_pos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipment_type`
--

DROP TABLE IF EXISTS `equipment_type`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `equipment_type` (
  `equipmenttypeid` tinyint(4) NOT NULL auto_increment COMMENT '序号',
  `equipmenttypeno` varchar(50) default NULL COMMENT '设备类型编号',
  `equipmenttypename` varchar(50) default NULL COMMENT '设备类型名',
  `opera` int(11) default NULL COMMENT '操作者',
  `uptime` datetime default NULL COMMENT '时间',
  PRIMARY KEY  (`equipmenttypeid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='药柜设备类型';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `equipment_type`
--

LOCK TABLES `equipment_type` WRITE;
/*!40000 ALTER TABLE `equipment_type` DISABLE KEYS */;
INSERT INTO `equipment_type` VALUES (1,'SBMODEL1','SBMODEL1',0,'2021-05-08 00:00:00'),(2,'SBMODEL2','SBMODEL2',0,'2021-05-08 00:00:00');
/*!40000 ALTER TABLE `equipment_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hospital`
--

DROP TABLE IF EXISTS `hospital`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `hospital` (
  `hospitalid` int(11) NOT NULL auto_increment,
  `hospitalname` varchar(50) default NULL COMMENT '医院名',
  `opera` int(11) default NULL COMMENT '工号',
  `uptime` datetime default NULL COMMENT '时间',
  `hospitalno` varchar(20) default NULL COMMENT '医院编号',
  PRIMARY KEY  (`hospitalid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='医院名';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `hospital`
--

LOCK TABLES `hospital` WRITE;
/*!40000 ALTER TABLE `hospital` DISABLE KEYS */;
INSERT INTO `hospital` VALUES (1,'HOSPITAL',1,'2021-05-08 00:00:00','H001');
/*!40000 ALTER TABLE `hospital` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instock_log`
--

DROP TABLE IF EXISTS `instock_log`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `instock_log` (
  `instockid` bigint(20) NOT NULL auto_increment,
  `inempid` int(11) default NULL,
  `inemp` varchar(40) default NULL COMMENT '入库人',
  `receiveempid` int(11) default NULL,
  `receiveemp` varchar(40) default NULL COMMENT '接收人',
  `stockno` int(11) default NULL COMMENT '仓库号',
  `locationno` int(11) default NULL COMMENT '储位',
  `po` varchar(40) default NULL COMMENT '入库单号',
  `bottleid` bigint(20) default NULL,
  `bottleno` varchar(50) default NULL,
  `medicineid` int(11) default NULL,
  `medicineno` varchar(40) default NULL COMMENT '药编码',
  `intype` tinyint(4) default NULL COMMENT '入库类型',
  `datecode` int(11) default NULL COMMENT 'datacode',
  `validday` int(11) default NULL COMMENT '有效期',
  `weight` double(18,2) default NULL COMMENT '重量',
  `memo` varchar(50) default NULL COMMENT '备注',
  `opera` int(11) default NULL COMMENT '操作者',
  `inserttime` datetime default NULL COMMENT '插入时间',
  `delemp` int(11) default NULL COMMENT '删除人',
  `deltime` datetime default NULL COMMENT '删除时间',
  `manufacturer` varchar(40) default NULL COMMENT '厂商',
  PRIMARY KEY  (`instockid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='入库log';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `instock_log`
--

LOCK TABLES `instock_log` WRITE;
/*!40000 ALTER TABLE `instock_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `instock_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medi_trans`
--

DROP TABLE IF EXISTS `medi_trans`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `medi_trans` (
  `transid` bigint(20) NOT NULL auto_increment,
  `medicationid` int(11) default NULL,
  `medication_detailid` bigint(20) default NULL,
  `medicineid` int(11) default NULL,
  `bottleid` int(11) default NULL,
  `cabinetid` int(11) default NULL,
  `cabinet_cellid` int(11) default NULL,
  `equipmentid` int(11) default NULL,
  `equipment_posid` int(11) default NULL,
  `equipment_pos_degree` smallint(6) default NULL,
  `qtyapply` double(18,2) default NULL,
  `qtyrelease` double(18,2) default NULL,
  `weight1` double(18,2) default NULL,
  `weight2` double(18,2) default NULL,
  `status` smallint(6) default NULL,
  `opera` int(11) default NULL,
  `uptime` datetime default NULL,
  PRIMARY KEY  (`transid`),
  UNIQUE KEY `medication_detailid` (`medication_detailid`),
  KEY `medicationid` (`medicationid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `medi_trans`
--

LOCK TABLES `medi_trans` WRITE;
/*!40000 ALTER TABLE `medi_trans` DISABLE KEYS */;
INSERT INTO `medi_trans` VALUES (1,1,1,1,1,1,1,1,1,NULL,5.00,100.00,100.00,0.00,303,1,'2021-05-17 14:14:40'),(2,1,4,3,4,1,3,1,2,NULL,8.00,20.00,100.00,80.00,307,1,'2021-05-17 11:11:23');
/*!40000 ALTER TABLE `medi_trans` ENABLE KEYS */;
UNLOCK TABLES;

/*!50003 SET @SAVE_SQL_MODE=@@SQL_MODE*/;

DELIMITER ;;
/*!50003 SET SESSION SQL_MODE="" */;;
/*!50003 CREATE */ /*!50017 DEFINER=`i3u`@`localhost` */ /*!50003 TRIGGER `medi_trans_update` BEFORE UPDATE ON `medi_trans` FOR EACH ROW BEGIN
if new.status=303 then
if new.weight1<=0 then
set new.bottleid=null;
end if;
INSERT INTO bottle_transaction (bottleid,medicineid,weight_cur,opera,uptime,uses_flag) VALUES(
new.bottleid,new.medicineid,new.weight1,new.opera,new.uptime,104);
ELSEIF new.status=304 OR new.status=305 then
INSERT INTO bottle_transaction (bottleid,medicineid,opera,uptime,uses_flag) VALUES(
new.bottleid,new.medicineid,new.opera,new.uptime,105);
elseif new.status=306 then
IF new.weight2<=0 THEN
SET new.bottleid=NULL;
END IF;
INSERT INTO bottle_transaction (bottleid,medicineid,weight_cur,opera,uptime,uses_flag) VALUES(
new.bottleid,new.medicineid,new.weight2,new.opera,new.uptime,106);
ELSEIF new.status=307 THEN
INSERT INTO bottle_transaction (bottleid,medicineid,opera,uptime,uses_flag) VALUES(
new.bottleid,new.medicineid,new.opera,new.uptime,107);
end if;
    END */;;

DELIMITER ;
/*!50003 SET SESSION SQL_MODE=@SAVE_SQL_MODE*/;

--
-- Table structure for table `medication`
--

DROP TABLE IF EXISTS `medication`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `medication` (
  `medicationid` bigint(20) NOT NULL auto_increment,
  `dispensaryid` int(11) default NULL,
  `medication_no` varchar(30) default NULL COMMENT '处方号',
  `kebie_name` varchar(50) default NULL COMMENT '科别',
  `doctor_no` varchar(50) default NULL COMMENT '医生',
  `patient_name` varchar(50) default NULL COMMENT '姓名',
  `patient_sex` varchar(5) default NULL COMMENT '性别',
  `patient_age` tinyint(4) default NULL COMMENT '年龄',
  `patient_phoneno` varchar(20) default NULL COMMENT '电话',
  `patient_fresh` tinyint(1) default NULL COMMENT '是否首次',
  `patient_address` varchar(50) default NULL COMMENT '地址',
  `patient_fallill_time` datetime default NULL COMMENT '生病时间',
  `patient_intime` datetime default NULL COMMENT '看病时间',
  `patient_allergy` varchar(100) default NULL COMMENT '过敏史',
  `patient_historyilldes` varchar(100) default NULL COMMENT '病史',
  `patient_illshow` varchar(100) default NULL COMMENT '病表现',
  `doctory_diagnosis` varchar(100) default NULL COMMENT '诊断',
  `doctory_medicineprescript` varchar(100) default NULL COMMENT '药方',
  `doctory_medicinefundesc` varchar(100) default NULL COMMENT '药效',
  `doctory_usemethod` varchar(100) default NULL COMMENT '使用方法',
  `danji_price` double(10,2) default NULL COMMENT '单剂价格',
  `jici` int(5) default NULL COMMENT '剂次',
  `total_price` double(10,2) default NULL COMMENT '总价',
  `opera` int(11) default NULL COMMENT '操作人',
  `uptime` datetime default NULL COMMENT '更新时间',
  `status` smallint(5) unsigned default '200' COMMENT '状态',
  PRIMARY KEY  (`medicationid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='处方录入';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `medication`
--

LOCK TABLES `medication` WRITE;
/*!40000 ALTER TABLE `medication` DISABLE KEYS */;
INSERT INTO `medication` VALUES (1,1,'H001000820210508175840','','ADMIN','EMP','?',2,'134',0,'AD','2021-05-08 00:00:00','2021-05-08 00:00:00','','','T1','T1','T1','T1','T1',500.00,10,5000.00,0,'2021-05-08 00:00:00',200),(2,1,'H001000820210508180247','','ADMIN','EMP2','',0,'',0,'','2021-05-08 00:00:00','2021-05-08 00:00:00','','','T','T','T','T','T',500.00,0,0.00,0,'2021-05-08 00:00:00',200);
/*!40000 ALTER TABLE `medication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medication_detail`
--

DROP TABLE IF EXISTS `medication_detail`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `medication_detail` (
  `medication_detailid` bigint(20) NOT NULL auto_increment,
  `medicationid` bigint(20) NOT NULL,
  `medication_no` varchar(50) default NULL COMMENT '处方号',
  `medicineid` int(11) default NULL,
  `medicineno` varchar(50) default NULL COMMENT '药编号',
  `medicinenocn` varchar(50) default NULL COMMENT '药名',
  `price` double(10,2) default NULL COMMENT '价格',
  `jiliang` int(10) default NULL COMMENT '剂量',
  `xiaoji` double(10,2) default NULL COMMENT '小计',
  `status` smallint(6) default '300' COMMENT '状态',
  `time1` datetime default NULL COMMENT '时间',
  PRIMARY KEY  (`medication_detailid`),
  UNIQUE KEY `medicineid` (`medicationid`,`medicineid`),
  KEY `FK_medication_detail` (`medicationid`),
  CONSTRAINT `FK_medication_detail` FOREIGN KEY (`medicationid`) REFERENCES `medication` (`medicationid`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='处方明细';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `medication_detail`
--

LOCK TABLES `medication_detail` WRITE;
/*!40000 ALTER TABLE `medication_detail` DISABLE KEYS */;
INSERT INTO `medication_detail` VALUES (1,1,'H001000820210508175840',1,'H0201900','M2',50.00,5,250.00,300,'0000-00-00 00:00:00'),(3,2,'H001000820210508180247',1,'H0201900','M2',50.00,10,500.00,300,'0000-00-00 00:00:00'),(4,1,NULL,3,'H0201902','M4',50.00,8,400.00,300,'2021-05-16 19:46:59');
/*!40000 ALTER TABLE `medication_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicine_control`
--

DROP TABLE IF EXISTS `medicine_control`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `medicine_control` (
  `controlid` int(11) NOT NULL auto_increment,
  `medicineid` varchar(20) default NULL COMMENT '药编号1',
  `medicine2id` varchar(20) default NULL COMMENT '要编号2',
  `explains` varchar(50) default NULL COMMENT '说明',
  `relation` tinyint(4) default NULL COMMENT '状态',
  `memo` varchar(50) default NULL COMMENT '备注',
  `opera` int(11) default NULL COMMENT '操作者',
  `uptime` datetime default NULL COMMENT '时间',
  `medicinename` varchar(40) default NULL COMMENT '药名1',
  `medicine2name` varchar(40) default NULL COMMENT '药名2',
  `delemp` int(11) default NULL COMMENT '删除人',
  `deltime` datetime default NULL COMMENT '删除时间',
  PRIMARY KEY  (`controlid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='配伍禁忌';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `medicine_control`
--

LOCK TABLES `medicine_control` WRITE;
/*!40000 ALTER TABLE `medicine_control` DISABLE KEYS */;
INSERT INTO `medicine_control` VALUES (1,'H0201900','H0201901','',0,'',0,'2021-05-08 00:00:00','M2','M3',0,'0000-00-00 00:00:00'),(2,'H0201900','H0201902','',0,'',0,'2021-05-08 00:00:00','M2','M4',0,'2021-05-08 00:00:00');
/*!40000 ALTER TABLE `medicine_control` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicine_control_type`
--

DROP TABLE IF EXISTS `medicine_control_type`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `medicine_control_type` (
  `relationid` int(11) NOT NULL auto_increment,
  `relationtype` varchar(20) default NULL,
  `memo` varchar(100) default NULL,
  `opera` int(11) default NULL,
  `uptime` datetime default NULL,
  PRIMARY KEY  (`relationid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `medicine_control_type`
--

LOCK TABLES `medicine_control_type` WRITE;
/*!40000 ALTER TABLE `medicine_control_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `medicine_control_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicine_info`
--

DROP TABLE IF EXISTS `medicine_info`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `medicine_info` (
  `medicineid` int(11) NOT NULL auto_increment COMMENT 'SEQ',
  `tiaojino` varchar(50) default NULL COMMENT '调机码',
  `packno` varchar(50) default NULL COMMENT '包装码',
  `medicineno` varchar(50) default NULL COMMENT '药编号',
  `medicinenocn` varchar(50) default NULL COMMENT '药名中文',
  `medicinenopy` varchar(50) default NULL COMMENT '药名拼音',
  `density` double(10,2) default NULL,
  `equivalent` int(11) default NULL,
  `ispoison` tinyint(1) default '0' COMMENT '毒药',
  `isanesthetic` tinyint(1) default '0' COMMENT '麻药',
  `currentqty` double(18,2) default NULL COMMENT '当前数量',
  `price` double(18,2) default NULL COMMENT '价格',
  `warningval_jiliang` double(18,2) default NULL,
  `warningval_stock` int(5) default NULL COMMENT '库存安全值',
  `warningval_cabinet` int(5) default NULL COMMENT '药柜安全值',
  `warning_validdays` int(5) default NULL COMMENT '有效期报警值',
  `opera` int(11) default NULL COMMENT '操作员',
  `uptime` datetime default NULL COMMENT '时间',
  `publicqty` double(18,2) default NULL,
  PRIMARY KEY  (`medicineid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='颗粒基本信息';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `medicine_info`
--

LOCK TABLES `medicine_info` WRITE;
/*!40000 ALTER TABLE `medicine_info` DISABLE KEYS */;
INSERT INTO `medicine_info` VALUES (1,'201900','K073','H0201900','M2','',NULL,NULL,0,0,2161.00,50.00,NULL,60,30,30,0,'2020-11-26 00:00:00',250.00),(2,'211011','K059','H0201901','M3','',NULL,NULL,0,0,1740.00,50.00,NULL,60,30,30,0,'2020-11-26 00:00:00',250.00),(3,'220122','K045','H0201902','M4','',NULL,NULL,0,0,871.00,50.00,NULL,60,30,30,0,'2020-11-26 00:00:00',250.00),(4,'229233','K031','H0201903','M5','',NULL,NULL,0,0,1750.00,50.00,NULL,60,30,30,0,'2020-11-26 00:00:00',250.00),(5,'238344','K017','H0201904','M6','',NULL,NULL,0,0,-250.00,50.00,NULL,60,30,30,0,'2020-11-26 00:00:00',250.00),(6,'247455','K003','H0201905','M7','',NULL,NULL,0,0,-250.00,50.00,NULL,60,30,30,0,'2020-11-26 00:00:00',250.00),(7,'256566','K011','H0201906','M8','',NULL,NULL,0,0,-250.00,50.00,NULL,60,30,30,0,'2020-11-26 00:00:00',250.00),(8,'265677','K025','H0201907','M9','',NULL,NULL,0,0,-250.00,50.00,NULL,60,30,30,0,'2020-11-26 00:00:00',250.00),(9,'274788','K039','H0201908','M10','',NULL,NULL,0,0,-250.00,50.00,NULL,60,30,30,0,'2020-11-26 00:00:00',250.00),(10,'283899','K053','H0201909','M11','',NULL,NULL,0,0,-250.00,50.00,NULL,60,30,30,0,'2020-11-26 00:00:00',250.00),(11,'293010','K067','H0201910','M12','',NULL,NULL,0,0,-250.00,50.00,NULL,60,30,30,0,'2020-11-26 00:00:00',250.00),(12,'302121','K081','H0201911','M1','',NULL,NULL,0,0,-1250.00,50.00,NULL,60,30,30,0,'2020-11-26 00:00:00',250.00);
/*!40000 ALTER TABLE `medicine_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicine_loc_cabinet`
--

DROP TABLE IF EXISTS `medicine_loc_cabinet`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `medicine_loc_cabinet` (
  `locationid` bigint(20) NOT NULL auto_increment,
  `equipmentno` varchar(50) default NULL COMMENT '设备编码',
  `medicineid` int(11) default NULL COMMENT '药物编码',
  `medicineno` varchar(50) default NULL COMMENT '药物编码',
  `cabinetid` int(11) default NULL COMMENT '柜号',
  `layoutid_row` tinyint(4) default NULL COMMENT '药行',
  `layoutid_col` tinyint(4) default NULL COMMENT '药列',
  `layout_row` tinyint(4) default NULL COMMENT '药柜行数',
  `layout_col` tinyint(4) default NULL COMMENT '药柜列数',
  `layout_rowwidth` smallint(6) default NULL COMMENT '药格宽',
  `layout_rowheight` smallint(6) default NULL COMMENT '药格高',
  `medicine_location` varchar(50) default NULL COMMENT 'LOCATION',
  `medicine_cur_qty` int(11) default NULL COMMENT '当前数量',
  `opera` int(11) default NULL COMMENT '操作员',
  `uptime` datetime default NULL COMMENT '更新时间',
  `bottleid` bigint(20) default NULL COMMENT '瓶号',
  PRIMARY KEY  (`locationid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='调剂设备药格配置';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `medicine_loc_cabinet`
--

LOCK TABLES `medicine_loc_cabinet` WRITE;
/*!40000 ALTER TABLE `medicine_loc_cabinet` DISABLE KEYS */;
INSERT INTO `medicine_loc_cabinet` VALUES (1,'SBNO1',1,'H0201900',1,1,1,10,10,80,40,'',1000,0,'2021-05-08 00:00:00',0),(2,'SBNO1',2,'H0201901',1,2,1,10,10,80,40,'',1000,0,'2021-05-08 00:00:00',0),(3,'SBNO1',3,'H0201902',1,3,1,10,10,80,40,'',1000,0,'2021-05-08 00:00:00',0),(4,'SBNO1',4,'H0201903',1,4,1,10,10,80,40,'',0,0,'2021-05-08 00:00:00',0),(5,'SBNO1',5,'H0201904',1,5,1,10,10,80,40,'',0,0,'2021-05-08 00:00:00',0),(6,'SBNO1',6,'H0201905',1,6,1,10,10,80,40,'',0,0,'2021-05-08 00:00:00',0),(7,'SBNO1',7,'H0201906',1,7,1,10,10,80,40,'',0,0,'2021-05-08 00:00:00',0),(8,'SBNO1',8,'H0201907',1,8,1,10,10,80,40,'',0,0,'2021-05-08 00:00:00',0),(9,'SBNO1',9,'H0201908',1,9,1,10,10,80,40,'',0,0,'2021-05-08 00:00:00',0),(10,'SBNO1',10,'H0201909',1,10,1,10,10,80,40,'',0,0,'2021-05-08 00:00:00',0),(11,'SBNO1',11,'H0201910',1,1,2,10,10,80,40,'',0,0,'2021-05-08 00:00:00',0),(12,'SBNO1',12,'H0201911',1,2,2,10,10,80,40,'',0,0,'2021-05-08 00:00:00',0);
/*!40000 ALTER TABLE `medicine_loc_cabinet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicineequipment_base`
--

DROP TABLE IF EXISTS `medicineequipment_base`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `medicineequipment_base` (
  `equipmentno` varchar(50) default NULL COMMENT '设备编号',
  `equipmentname` varchar(50) default NULL COMMENT '设备名',
  `ip` varchar(50) default NULL COMMENT 'ip',
  `status` tinyint(1) default NULL COMMENT '状态',
  `equipmenttype` varchar(30) default NULL COMMENT '设备类型',
  `opera` varchar(15) default NULL COMMENT '操作者',
  `uptime` date default NULL COMMENT '时间',
  `seq` int(5) default NULL COMMENT '序号',
  `bindstatus` varchar(2) default NULL COMMENT '绑定状态'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='药柜设备基本信息';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `medicineequipment_base`
--

LOCK TABLES `medicineequipment_base` WRITE;
/*!40000 ALTER TABLE `medicineequipment_base` DISABLE KEYS */;
INSERT INTO `medicineequipment_base` VALUES ('SBNO1','SBNO1','192.168.0.200',1,'SBMODEL1','ADMIN','2021-05-08',1,'');
/*!40000 ALTER TABLE `medicineequipment_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `menu` (
  `tableid` varchar(50) default NULL COMMENT 'tableid',
  `menuid` varchar(50) default NULL COMMENT '菜单id',
  `menuname` varchar(50) default NULL COMMENT '菜单名',
  `parentmenu` varchar(50) default NULL COMMENT '父菜单',
  `grade` varchar(50) default NULL COMMENT '层',
  `flag` varchar(50) default NULL COMMENT 'flag',
  `href` varchar(200) default NULL COMMENT 'href',
  `uptime` date default NULL COMMENT '时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='菜单';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `mt_cc_b_m`
--

DROP TABLE IF EXISTS `mt_cc_b_m`;
/*!50001 DROP VIEW IF EXISTS `mt_cc_b_m`*/;
/*!50001 CREATE TABLE `mt_cc_b_m` (
  `bottleno` varchar(50),
  `medicineno` varchar(50),
  `jiliang` int(10),
  `statusname` varchar(10),
  `cabinetname` varchar(50),
  `cell` varbinary(9),
  `mqtt_light` varbinary(76),
  `mqtt_pos` varbinary(70),
  `mqtt_ind_shangdai` varchar(71),
  `mqtt_ind_fengdai` varchar(70),
  `mqtt_ind_startstop` varchar(72),
  `mqtt_getweight` varchar(68),
  `mqtt_return_finish` varchar(72),
  `equipmentname` varchar(50),
  `pos_idx` tinyint(4),
  `medicinenocn` varchar(50),
  `medicinenopy` varchar(50),
  `op_idx` int(11),
  `op_code` int(11),
  `price` double(10,2),
  `xiaoji` double(10,2),
  `medication_no` varchar(50),
  `computer_name` varchar(40),
  `status` int(6),
  `time1` datetime,
  `equipmentid` int(11),
  `equipment_posid` int(11),
  `equipment_pos_degree` smallint(6),
  `qtyapply` double(18,2),
  `qtyrelease` double(18,2),
  `weight1` double(18,2),
  `weight2` double(18,2),
  `transid` bigint(20),
  `computerid` int(11),
  `cabinetid` int(11),
  `cellid` int(11),
  `bottleid` bigint(20),
  `medicineid` int(11),
  `medication_detailid` bigint(20),
  `medicationid` bigint(20)
) */;

--
-- Table structure for table `status_option`
--

DROP TABLE IF EXISTS `status_option`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `status_option` (
  `idx` smallint(5) unsigned NOT NULL auto_increment,
  `used4` varchar(10) NOT NULL,
  `typename` varchar(10) NOT NULL,
  `statustype` tinyint(3) unsigned NOT NULL,
  `statuscode` smallint(5) unsigned NOT NULL,
  `statusname` varchar(10) default NULL,
  `remark` varchar(100) default NULL,
  PRIMARY KEY  (`idx`),
  UNIQUE KEY `pk_tc_tablestatus` (`used4`,`statuscode`),
  KEY `statuscode` (`statuscode`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `status_option`
--

LOCK TABLES `status_option` WRITE;
/*!40000 ALTER TABLE `status_option` DISABLE KEYS */;
INSERT INTO `status_option` VALUES (1,'bottle','status',1,100,'采购待入库','未入库前的状态'),(2,'bottle','status',1,101,'采购入库',NULL),(3,'bottle','status',1,102,'领药出库',NULL),(4,'bottle','status',1,103,'领药上柜',NULL),(5,'bottle','status',1,104,'发药称重',NULL),(6,'bottle','status',1,105,'上药机',NULL),(7,'bottle','status',1,106,'下机称重',NULL),(8,'bottle','status',1,107,'发药回柜',NULL),(9,'bottle','status',1,108,'退药回库',NULL),(10,'bottle','status',1,109,'药瓶回收',NULL),(11,'medication','status',2,200,'处方录入',NULL),(12,'medication','status',2,201,'录入完成',NULL),(13,'medication','status',2,202,'已确认',NULL),(14,'medication','status',2,203,'核验失败',NULL),(15,'medication','status',2,204,'已核验',NULL),(16,'medication','status',2,205,'待发药',NULL),(17,'medication','status',2,206,'发药中',NULL),(18,'medication','status',2,207,'发药失败',NULL),(19,'medication','status',2,208,'发药完成',NULL),(20,'medication','status',2,209,'已交付',NULL),(21,'medication','status',3,300,'录入',NULL),(22,'medication','status',3,301,'待发药',NULL),(23,'medication','status',3,302,'取药',NULL),(24,'medication','status',3,303,'发药称重',NULL),(25,'medication','status',3,304,'上药机',NULL),(26,'medication','status',3,305,'发药中',NULL),(27,'medication','status',3,306,'下机称重',NULL),(28,'medication','status',3,307,'回柜',NULL),(29,'medication','status',3,308,'发药失败',NULL),(30,'medication','status',3,309,'发药成功',NULL);
/*!40000 ALTER TABLE `status_option` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stockbaseinfo`
--

DROP TABLE IF EXISTS `stockbaseinfo`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `stockbaseinfo` (
  `stockid` int(11) NOT NULL auto_increment,
  `dispensaryid` int(11) default NULL,
  `stockno` varchar(5) default NULL COMMENT '药库码',
  `stockname` varchar(50) default NULL COMMENT '药库名',
  `guige` varchar(50) default NULL COMMENT '规格',
  `locations` varchar(50) default NULL COMMENT '位置',
  `memo` varchar(50) default NULL COMMENT '备注',
  `opera` int(11) default NULL COMMENT '操作员',
  `uptime` datetime default NULL COMMENT '时间',
  `delemp` int(11) default NULL COMMENT '删除人',
  `deltime` datetime default NULL COMMENT '删除时间',
  `status` tinyint(2) default NULL COMMENT '状态',
  PRIMARY KEY  (`stockid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC COMMENT='药房仓库基本信息';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `stockbaseinfo`
--

LOCK TABLES `stockbaseinfo` WRITE;
/*!40000 ALTER TABLE `stockbaseinfo` DISABLE KEYS */;
INSERT INTO `stockbaseinfo` VALUES (1,1,'1','CANGKUNO2','AA','3F','AA',1,'2021-05-08 00:00:00',0,'0000-00-00 00:00:00',1),(2,1,'2','CANGKUNO1','TT','2F','TT',0,'2021-05-08 00:00:00',0,'0000-00-00 00:00:00',127);
/*!40000 ALTER TABLE `stockbaseinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stocklocationinfo`
--

DROP TABLE IF EXISTS `stocklocationinfo`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `stocklocationinfo` (
  `locationid` int(11) NOT NULL auto_increment,
  `stockid` int(11) NOT NULL,
  `stockno` varchar(5) default NULL COMMENT '仓库编号',
  `location_no` varchar(50) default NULL COMMENT '位置码',
  `location_name` varchar(50) default NULL COMMENT '位置名',
  `location_guige` varchar(50) default NULL COMMENT '位置规格',
  `location_status` varchar(2) default NULL COMMENT '位置状态',
  `memo` varchar(50) default NULL COMMENT '备注',
  `opera` int(11) default NULL COMMENT '操作员',
  `insert_time` datetime default NULL COMMENT '时间',
  `delemp` int(11) default NULL COMMENT '删除人',
  `deltime` datetime default NULL COMMENT '删除时间',
  PRIMARY KEY  (`locationid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='储位信息';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `stocklocationinfo`
--

LOCK TABLES `stocklocationinfo` WRITE;
/*!40000 ALTER TABLE `stocklocationinfo` DISABLE KEYS */;
INSERT INTO `stocklocationinfo` VALUES (1,1,'1','001','CHUWEI1','1','1','',0,'2021-05-08 00:00:00',0,'0000-00-00 00:00:00'),(2,1,'1','002','CHUWEI1','1','1','',0,'2021-05-08 00:00:00',0,'0000-00-00 00:00:00');
/*!40000 ALTER TABLE `stocklocationinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_role` (
  `role_id` int(11) NOT NULL auto_increment COMMENT '角色id',
  `role_name` varchar(50) default NULL COMMENT '角色名',
  `layout` varchar(50) default NULL COMMENT '菜单id',
  `insert_time` datetime default NULL COMMENT '操作时间',
  `insert_emp` int(11) default NULL,
  `opera` int(11) default NULL COMMENT '操作员',
  `del_opera` int(11) default NULL COMMENT '删除人',
  `del_time` datetime default NULL COMMENT '删除时间',
  PRIMARY KEY  (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='角色';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` VALUES (1,'admin','layout/ucin/his/common.xml','2021-05-12 11:16:11',0,0,NULL,NULL);
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_name` varchar(30) default NULL COMMENT '用户名',
  `user_pass` varchar(50) default NULL COMMENT '密码',
  `user_role` tinyint(4) default NULL COMMENT '类型',
  `ap_name` varchar(30) default NULL COMMENT 'AP',
  `user_str` varchar(100) default NULL,
  `dept_info` smallint(6) default NULL COMMENT '部门',
  `memo` varchar(100) default NULL COMMENT '备注',
  `real_name` varchar(30) default NULL COMMENT '真实名字',
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='登录用户';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','e10adc3949ba59abbe56e057f20f883e',1,'','',0,'','张三');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xiefang_detail`
--

DROP TABLE IF EXISTS `xiefang_detail`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `xiefang_detail` (
  `xiefang_detailid` int(11) NOT NULL auto_increment,
  `xiefangid` int(11) default NULL COMMENT '协方号',
  `medicineid` int(11) default NULL,
  `medicinenopy` varchar(50) default NULL COMMENT '协方名拼音',
  `medicinenocn` varchar(50) default NULL COMMENT '协方名汉子',
  `medicine_pweight` int(10) default NULL COMMENT '参考剂量',
  `delemp` int(11) default NULL COMMENT '删除人',
  `deltime` datetime default NULL COMMENT '删除时间',
  `medicineno` varchar(50) default NULL COMMENT '药物编码',
  PRIMARY KEY  (`xiefang_detailid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='协方明细';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `xiefang_detail`
--

LOCK TABLES `xiefang_detail` WRITE;
/*!40000 ALTER TABLE `xiefang_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `xiefang_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xiefang_t`
--

DROP TABLE IF EXISTS `xiefang_t`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `xiefang_t` (
  `xiefangid` int(11) NOT NULL auto_increment,
  `xiefang_no` varchar(50) default NULL COMMENT '协方编号',
  `xiefang_name` varchar(50) default NULL COMMENT '协方名',
  `xiefang_forill` varchar(50) default NULL COMMENT '协方针对',
  `xiefang_jianyiji` int(10) default NULL COMMENT '协方建议剂次',
  `xiefang_chuchu` varchar(50) default NULL COMMENT '协方出处',
  `opera` int(11) default NULL COMMENT '操作员',
  `huanzhe_fallill_time` datetime default NULL,
  `deltime` datetime default NULL COMMENT '删除时间',
  `delemp` int(20) default NULL COMMENT '删除人',
  `status` tinyint(2) default NULL COMMENT '状态',
  PRIMARY KEY  (`xiefangid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='协方';
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `xiefang_t`
--

LOCK TABLES `xiefang_t` WRITE;
/*!40000 ALTER TABLE `xiefang_t` DISABLE KEYS */;
/*!40000 ALTER TABLE `xiefang_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'his'
--
DELIMITER ;;
/*!50003 DROP PROCEDURE IF EXISTS `PrepareMed` */;;
/*!50003 SET SESSION SQL_MODE=""*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`i3u`@`localhost`*/ /*!50003 PROCEDURE `PrepareMed`(medid INT,userid INT)
BEGIN
DECLARE dt DATE;
DECLARE i INT;
#IF cc!='' THEN
#IF dtStart IS NULL AND dtEnd IS NULL THEN
#SELECT calendar_start_date,calendar_end_date INTO dtStart,dtEnd FROM bom_calendars WHERE calendar_code=cc;
#END IF;
#IF dtStart IS NOT NULL AND dtEnd IS NOT NULL THEN
SET i=1;
#    SELECT SUBDATE(dtStart,DATE_FORMAT(dtStart,'%w')-7) INTO dt;
WHILE i<6 DO
INSERT INTO his.medi_trans 
(medicationid,medication_detailid,medicineid,bottleid,cabinetid,cabinet_cellid,equipmentid,equipment_posid,equipment_pos_degree,qtyapply,qtyrelease,weight1,weight2,STATUS,opera,uptime)
SELECT 	medicationid,medication_detailid,medicineid,bottleid,cabinetid,cellid,equipmentid,i,equipment_pos_degree,qtyapply,qtyrelease,weight1,weight2,301,userid,NOW() FROM mt_cc_b_m WHERE medicationid=medid and status=300 limit 0,1;
SET i = i+1;
END WHILE;
#END IF;
#END IF;
    END */;;
/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE*/;;
DELIMITER ;

--
-- Current Database: `his`
--

USE `his`;

--
-- Final view structure for view `mt_cc_b_m`
--

/*!50001 DROP TABLE `mt_cc_b_m`*/;
/*!50001 DROP VIEW IF EXISTS `mt_cc_b_m`*/;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`i3u`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `mt_cc_b_m` AS (select `b`.`bottleno` AS `bottleno`,`m`.`medicineno` AS `medicineno`,`m`.`jiliang` AS `jiliang`,`st`.`statusname` AS `statusname`,`c`.`cabinetname` AS `cabinetname`,concat(`cc`.`cell_row`,_utf8'-',`cc`.`cell_col`) AS `cell`,concat(_utf8'devices/',`c`.`cabinetname`,_utf8'/light/',`cc`.`op_idx`) AS `mqtt_light`,concat(_utf8'devices/',`e`.`equipmentname`,_utf8'/plc_pos',`ep`.`pos_idx`) AS `mqtt_pos`,concat(_utf8'devices/',`e`.`equipmentname`,_utf8'/ind_shangdai') AS `mqtt_ind_shangdai`,concat(_utf8'devices/',`e`.`equipmentname`,_utf8'/ind_fengdai') AS `mqtt_ind_fengdai`,concat(_utf8'devices/',`e`.`equipmentname`,_utf8'/ind_startstop') AS `mqtt_ind_startstop`,concat(_utf8'devices/',`e`.`equipmentname`,_utf8'/getweight') AS `mqtt_getweight`,concat(_utf8'devices/',`e`.`equipmentname`,_utf8'/return_finish') AS `mqtt_return_finish`,`e`.`equipmentname` AS `equipmentname`,`ep`.`pos_idx` AS `pos_idx`,`m`.`medicinenocn` AS `medicinenocn`,`m0`.`medicinenopy` AS `medicinenopy`,`cc`.`op_idx` AS `op_idx`,`cc`.`op_code` AS `op_code`,`m`.`price` AS `price`,`m`.`xiaoji` AS `xiaoji`,`m`.`medication_no` AS `medication_no`,`cp`.`computer_name` AS `computer_name`,ifnull(`mt`.`status`,`m`.`status`) AS `status`,`m`.`time1` AS `time1`,`e`.`equipmentid` AS `equipmentid`,`mt`.`equipment_posid` AS `equipment_posid`,`mt`.`equipment_pos_degree` AS `equipment_pos_degree`,`mt`.`qtyapply` AS `qtyapply`,`mt`.`qtyrelease` AS `qtyrelease`,`mt`.`weight1` AS `weight1`,`mt`.`weight2` AS `weight2`,`mt`.`transid` AS `transid`,`cp`.`computerid` AS `computerid`,`c`.`cabinetid` AS `cabinetid`,`cc`.`cellid` AS `cellid`,`b`.`bottleid` AS `bottleid`,`m`.`medicineid` AS `medicineid`,`m`.`medication_detailid` AS `medication_detailid`,`m`.`medicationid` AS `medicationid` from ((((((((((`medication_detail` `m` left join `medicine_info` `m0` on((`m`.`medicineid` = `m0`.`medicineid`))) left join `bottle_loc_cabinet` `bc` on((`bc`.`medicineid` = `m0`.`medicineid`))) left join `cabinet_cell` `cc` on((`cc`.`cellid` = `bc`.`cellid`))) left join `cabinet` `c` on((`c`.`cabinetid` = `cc`.`cabinetid`))) left join `bottle_info` `b` on((`b`.`bottleid` = `bc`.`bottleid`))) left join `medi_trans` `mt` on((`mt`.`medication_detailid` = `m`.`medication_detailid`))) left join `status_option` `st` on((ifnull(`mt`.`status`,`m`.`status`) = `st`.`statuscode`))) left join `equipment` `e` on((`e`.`cabinetid` = `c`.`cabinetid`))) left join `equipment_pos` `ep` on((`ep`.`posid` = `mt`.`equipment_posid`))) left join `computers` `cp` on((`cp`.`computerid` = `e`.`computerid`)))) */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-19  7:08:40
